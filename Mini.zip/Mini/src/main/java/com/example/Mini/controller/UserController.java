package com.example.Mini.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.example.Mini.model.User;
import com.example.Mini.service.UserService;
import com.example.Mini.service.UserServiceImpl;
import com.example.Mini.web.dto.UserDto;



@Controller
public class UserController {
	
	@Autowired
	private UserServiceImpl userServiceImpl; 
	
	@Autowired
	private UserService userService; 
	
	
	
	@Autowired
	UserDetailsService userDetailsService;
	
	
	@PostMapping("/register")
	public String saveUser(@ModelAttribute("user") UserDto userDto,Model model) {
		userService.save(userDto);
		model.addAttribute("message", "Registered Successfully!");
		return "redirect:/loginfaculty";
	}
	
	@GetMapping("/register")
    public String showFacultyRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";  // Ensure this template exists 
    }

	
	@GetMapping("/loginfaculty")
    public String showFacultyLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "loginfaculty";
    }

    @PostMapping("/loginfaculty")
    public String loginFaculty(@ModelAttribute UserDto userDto, Model model) {
        User loggedInUser = userDto.findByEmail(userDto.getEmail());
        if (loggedInUser != null && userDto.checkPassword(userDto.getPassword(), userDto.getPassword())) {
            model.addAttribute("user", loggedInUser);
            return "redirect:/index";
        } else {
            return "redirect:/loginfaculty?error=true";
        }
    }
    
    @GetMapping("/ten")
    public String showTop10Profiles(Model model) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        
        boolean isUserLoggedIn = authentication != null && authentication.isAuthenticated()
                                    && authentication.getAuthorities().stream()
                                        .anyMatch(role -> role.getAuthority().equals("USER"));
        
        
        model.addAttribute("userLoggedIn", isUserLoggedIn);
        
        return "ten";
    }
	

}
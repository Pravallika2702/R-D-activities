package com.example.Mini.service;

import org.springframework.stereotype.Service;

import com.example.Mini.model.User;
import com.example.Mini.web.dto.UserDto;

@Service
public interface UserService {
	
	User save (UserDto userDto);

}

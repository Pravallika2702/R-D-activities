function redirectToDashboard(dashboardName) {
	            
	            window.location.href = `/dashboard?name=${dashboardName}`;
	        }

	        function generateReport(dashboardName) {
	            alert("Generating report for " + dashboardName);
	            
	        }

            
const suggestionsData = [
"Computer Science",
"Information Technology",
"Mathematics",
"Artificial Intelligence",
"Machine Learning",
"Data Science",
"Cybersecurity",
"Software Engineering",
"Robotics",
"Bioinformatics"
];

function showSuggestions() {
const input = document.getElementById('search-input');
const suggestionsContainer = document.getElementById('suggestions');
const query = input.value.toLowerCase();


suggestionsContainer.innerHTML = '';

if (query.length === 0) {
    suggestionsContainer.style.display = 'none';
    return;
}

const filteredSuggestions = suggestionsData.filter(item => item.toLowerCase().includes(query));

if (filteredSuggestions.length === 0) {
    suggestionsContainer.style.display = 'none';
    return;
}


suggestionsContainer.style.display = 'block';
filteredSuggestions.forEach(suggestion => {
    const suggestionItem = document.createElement('div');
    suggestionItem.textContent = suggestion;
    suggestionItem.className = 'suggestion-item';
    suggestionItem.onclick = () => selectSuggestion(suggestion);
    suggestionsContainer.appendChild(suggestionItem);
});
}

function selectSuggestion(suggestion) {
document.getElementById('search-input').value = suggestion;
document.getElementById('suggestions').style.display = 'none';
}

function performSearch() {
const query = document.getElementById('search-input').value;
alert("Searching for: " + query);

}

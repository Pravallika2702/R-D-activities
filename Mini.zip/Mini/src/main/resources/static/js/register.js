document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('register-form');

    form.addEventListener('submit', function(event) {
        const password = document.getElementById('password').value;
        const email = document.getElementById('email').value;

        // Example of basic validation
        if (password.length < 6) {
            alert('Password must be at least 6 characters long.');
            event.preventDefault();
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            event.preventDefault();
        }
    });

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(String(email).toLowerCase());
    }
});
